"""Xamhub - a Minecraft launcher with mod support.

Run with:  python app.py
"""
import hashlib
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid as uuidlib
import webbrowser
from collections import deque
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from pathlib import Path

import minecraft_launcher_lib as mll
import webview

APP_VERSION = "1.0.0"
ROOT = Path(os.environ.get("XAMHUB_HOME", Path.home() / ".xamhub"))
MC_DIR = ROOT / "minecraft"          # shared versions, libraries, assets, java runtimes
INST_DIR = ROOT / "instances"        # one game folder per instance (mods, saves, configs)
BG_DIR = ROOT / "backgrounds"        # the image or video chosen as launcher background
FONT_DIR = ROOT / "fonts"            # a custom UI font, if you add one
STATE_FILE = ROOT / "xamhub.json"
UI_FILE = Path(__file__).parent / "ui" / "index.html"

LOGIN_PORT = 53682
REDIRECT_URI = f"http://localhost:{LOGIN_PORT}"   # register this exact URI in your Azure app
MODRINTH = "https://api.modrinth.com/v2"
UA = f"Xamhub/{APP_VERSION} (desktop launcher)"
LOADERS = ("vanilla", "fabric", "quilt", "forge")
MOD_LOADER_TAGS = {"fabric": ["fabric"], "quilt": ["quilt", "fabric"], "forge": ["forge"]}

DEFAULT_STATE = {
    "settings": {"client_id": "", "ram_mb": 4096, "lights": True, "theme": None,
                 "bg": {"kind": "none", "file": None, "dim": 0.45, "blur": 0},
                 "font": {"family": "bricolage", "file": None, "scale": 1.0},
                 "perf": {"jvm_flags": True, "high_priority": True, "prewarm": True},
                 "effect": {"kind": "embers", "amount": 1.0, "front": True},
                 "force_motion": False},
    "account": None,
    "instances": [],
    "selected": None,
}

_lock = threading.RLock()
WINDOW = None
GAME = {"busy": False, "proc": None}
MEDIA = {"port": 0}
HEX_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
THEME_KEYS = ("bg", "panel", "text", "accent", "accent2")
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
VIDEO_EXT = {".mp4", ".m4v", ".webm"}
MAX_BG_BYTES = 150 * 1024 * 1024
FONT_EXT = {".ttf", ".otf", ".woff", ".woff2"}
FONT_KEYS = ("bricolage", "outfit", "nunito", "space", "pixel", "mono", "system", "custom")
WARM = {"done": set(), "running": set()}
EFFECT_KEYS = ("embers", "snow", "rain", "fireflies", "petals", "stars", "none")

# G1 garbage-collector tuning widely used for Minecraft (based on Aikar's flags, minus AlwaysPreTouch,
# which slows startup). Smooths out the lag spikes caused by memory clean-up.
PERF_FLAGS = [
    "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
    "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
    "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40", "-XX:G1HeapRegionSize=8M",
    "-XX:G1ReservePercent=20", "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
    "-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
    "-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32",
    "-XX:+PerfDisableSharedMem", "-XX:MaxTenuringThreshold=1",
]

# Modrinth projects in the one-click performance pack. ModernFix also cuts game startup time.
PERF_MODS = {
    "fabric": ["sodium", "lithium", "ferrite-core", "modernfix", "entityculling", "immediatelyfast"],
    "quilt": ["sodium", "lithium", "ferrite-core", "modernfix", "entityculling", "immediatelyfast"],
    "forge": ["embeddium", "ferrite-core", "modernfix", "entityculling"],
}
LOGIN = {"active": False, "cancel": threading.Event(), "url": None}

LOGIN_PAGE = (
    '<!doctype html><meta charset="utf-8"><title>Xamhub</title>'
    '<body style="margin:0;height:100vh;display:grid;place-items:center;background:#14151c;color:#ece7da;font-family:system-ui,sans-serif">'
    '<div style="text-align:center"><h1 style="color:#f7b24a">TITLE</h1><p>MSG</p></div>'
)


# --------------------------------------------------------------------------- state

def load_state():
    ROOT.mkdir(parents=True, exist_ok=True)
    data = {}
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text("utf-8"))
        except (OSError, ValueError):
            data = {}
    state = json.loads(json.dumps(DEFAULT_STATE))
    state["settings"].update(data.get("settings", {}))
    state["settings"].pop("sound", None)
    state["settings"].pop("volume", None)
    for key in ("account", "instances", "selected"):
        if key in data:
            state[key] = data[key]
    return state


STATE = load_state()


def save_state():
    with _lock:
        ROOT.mkdir(parents=True, exist_ok=True)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(STATE, indent=2), "utf-8")
        tmp.replace(STATE_FILE)


def find_instance(iid):
    for inst in STATE["instances"]:
        if inst["id"] == iid:
            return inst
    raise KeyError("That instance no longer exists.")


def public_state():
    acct = STATE["account"]
    return {
        "settings": STATE["settings"],
        "account": {"name": acct["name"], "uuid": acct["uuid"]} if acct else None,
        "instances": STATE["instances"],
        "selected": STATE["selected"],
        "root": str(ROOT),
        "media_port": MEDIA["port"],
    }


def emit(event, **payload):
    if WINDOW is None:
        return
    try:
        WINDOW.evaluate_js(f"window.XH && XH.on({json.dumps(event)}, {json.dumps(payload)})")
    except Exception:
        pass


def http_json(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def open_path(path):
    path = str(path)
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# --------------------------------------------------------------------------- installing

def make_callback(label):
    st = {"status": "", "progress": 0, "max": 1}
    last = [0.0]

    def push(force=False):
        now = time.time()
        if not force and now - last[0] < 0.08:
            return
        last[0] = now
        emit("progress", label=label, status=st["status"], value=st["progress"], max=max(st["max"], 1))

    def set_status(text):
        st["status"] = text
        push(True)

    def set_progress(value):
        st["progress"] = value
        push()

    def set_max(value):
        st["max"] = value
        push(True)

    return {"setStatus": set_status, "setProgress": set_progress, "setMax": set_max}


def installed_ids():
    return [v["id"] for v in mll.utils.get_installed_versions(str(MC_DIR))]


def find_version_id(loader, mc):
    for vid in installed_ids():
        if loader == "vanilla" and vid == mc:
            return vid
        if loader == "fabric" and vid.startswith("fabric-loader-") and vid.endswith("-" + mc):
            return vid
        if loader == "quilt" and vid.startswith("quilt-loader-") and vid.endswith("-" + mc):
            return vid
        if loader == "forge" and "forge" in vid.lower() and mc in vid:
            return vid
    return None


def runtime_java(mc):
    """Path to the Java that Mojang ships for this Minecraft version (needed by the Forge installer)."""
    try:
        data = json.loads((MC_DIR / "versions" / mc / f"{mc}.json").read_text("utf-8"))
        component = data["javaVersion"]["component"]
        return mll.runtime.get_executable_path(component, str(MC_DIR))
    except Exception:
        return None


def ensure_installed(inst):
    mc, loader = inst["mc_version"], inst["loader"]
    vid = find_version_id(loader, mc)
    if vid and inst.get("installed"):
        return vid

    mc_dir = str(MC_DIR)
    cb = make_callback(f"Minecraft {mc}")
    mll.install.install_minecraft_version(mc, mc_dir, callback=cb)

    if loader != "vanilla":
        cb = make_callback(f"{loader.capitalize()} for {mc}")
        if loader == "fabric":
            mll.fabric.install_fabric(mc, mc_dir, callback=cb)
        elif loader == "quilt":
            mll.quilt.install_quilt(mc, mc_dir, callback=cb)
        elif loader == "forge":
            forge_version = mll.forge.find_forge_version(mc)
            if not forge_version:
                raise RuntimeError(f"There is no Forge build for Minecraft {mc}. Pick another version or loader.")
            mll.forge.install_forge_version(forge_version, mc_dir, callback=cb, java=runtime_java(mc))

    vid = find_version_id(loader, mc)
    if not vid:
        raise RuntimeError("The install finished but the version could not be found.")
    inst["installed"] = True
    save_state()
    return vid


# --------------------------------------------------------------------------- account

def fresh_account():
    acct = STATE["account"]
    if not acct:
        raise RuntimeError("Sign in with Microsoft first.")
    if time.time() - acct.get("saved_at", 0) < 3600:
        return acct
    cid = STATE["settings"]["client_id"].strip()
    try:
        data = mll.microsoft_account.complete_refresh(cid, None, REDIRECT_URI, acct["refresh_token"])
        STATE["account"] = account_from(data)
        save_state()
    except Exception as exc:
        raise RuntimeError("Your session expired. Sign in again from the account button.") from exc
    return STATE["account"]


def account_from(data):
    return {
        "name": data["name"],
        "uuid": data["id"],
        "access_token": data["access_token"],
        "refresh_token": data["refresh_token"],
        "saved_at": time.time(),
    }


# --------------------------------------------------------------------------- launching

def version_at_least(mc, target):
    nums = [int(x) for x in re.findall(r"\d+", mc)[:3]]
    nums += [0] * (3 - len(nums))
    return tuple(nums) >= tuple(target) + (0,) * (3 - len(target))


def jvm_args(ram):
    if not STATE["settings"]["perf"].get("jvm_flags", True):
        return [f"-Xmx{ram}M", f"-Xms{min(ram, 1024)}M"]
    # Fixed heap plus tuned G1 garbage collection: fewer and shorter lag spikes.
    return [f"-Xmx{ram}M", f"-Xms{ram}M"] + PERF_FLAGS


def quick_play_args(inst):
    """Arguments that make Minecraft skip the title screen and load a world or join a server."""
    qp = inst.get("quick_play") or {}
    kind, target = qp.get("type"), str(qp.get("target") or "").strip()
    if not target:
        return []
    modern = version_at_least(inst["mc_version"], (1, 20))
    if kind == "world" and modern:
        return ["--quickPlaySingleplayer", target]
    if kind == "server":
        if modern:
            return ["--quickPlayMultiplayer", target]
        host, _, port = target.partition(":")
        return ["--server", host] + (["--port", port] if port else [])
    return []


def warm_instance(iid):
    """Does the slow parts of launching ahead of time so pressing Play starts Java straight away:
    refreshes the sign-in token and pulls the game's files into the operating system's disk cache."""
    try:
        inst = find_instance(iid)
        if STATE["account"]:
            try:
                fresh_account()
            except Exception:
                pass
        if not inst.get("installed"):
            return
        vid = find_version_id(inst["loader"], inst["mc_version"])
        if not vid:
            return
        dummy = {"username": "Player", "uuid": "0" * 32, "token": "0"}
        cmd = mll.command.get_minecraft_command(vid, str(MC_DIR), dummy)
        files = cmd[cmd.index("-cp") + 1].split(os.pathsep) if "-cp" in cmd else []
        files += [str(p) for p in (INST_DIR / inst["id"] / "mods").glob("*.jar")]
        for file in files:
            try:
                with open(file, "rb") as fh:
                    while fh.read(1 << 20):
                        pass
            except OSError:
                pass
        WARM["done"].add(iid)
        emit("warm", iid=iid)
    except Exception:
        pass
    finally:
        WARM["running"].discard(iid)


def run_instance(iid):
    try:
        inst = find_instance(iid)
        acct = fresh_account()
        emit("state", phase="installing", iid=iid)
        vid = ensure_installed(inst)

        game_dir = INST_DIR / inst["id"]
        (game_dir / "mods").mkdir(parents=True, exist_ok=True)
        ram = int(inst.get("ram_mb") or STATE["settings"]["ram_mb"])
        options = {
            "username": acct["name"],
            "uuid": acct["uuid"],
            "token": acct["access_token"],
            "gameDirectory": str(game_dir),
            "launcherName": "Xamhub",
            "launcherVersion": APP_VERSION,
            "jvmArguments": jvm_args(ram),
        }
        cmd = mll.command.get_minecraft_command(vid, str(MC_DIR), options)
        cmd += quick_play_args(inst)

        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if STATE["settings"]["perf"].get("high_priority", True) and sys.platform.startswith("win"):
            flags |= 0x00008000  # ABOVE_NORMAL_PRIORITY_CLASS
        proc = subprocess.Popen(
            cmd, cwd=str(game_dir), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, errors="replace", creationflags=flags,
        )
        GAME["proc"] = proc
        inst["last_played"] = int(time.time())
        save_state()
        emit("state", phase="running", iid=iid)

        tail = deque(maxlen=40)
        for line in proc.stdout:
            tail.append(line.rstrip())
        code = proc.wait()
        WARM["done"].add(iid)   # its files are now in the disk cache
        emit("state", phase="closed", iid=iid, code=code, tail="\n".join(tail) if code else "")
    except Exception as exc:  # surface any failure in the UI instead of dying silently
        emit("state", phase="error", iid=iid, message=str(exc))
    finally:
        GAME["busy"] = False
        GAME["proc"] = None


# --------------------------------------------------------------------------- mods

def safe_name(name):
    if name != Path(name).name:
        raise ValueError("Invalid file name.")
    return name


def mods_dir(iid):
    path = INST_DIR / find_instance(iid)["id"] / "mods"
    path.mkdir(parents=True, exist_ok=True)
    return path


def download(url, dest, sha512=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    tmp = dest.with_suffix(dest.suffix + ".part")
    digest = hashlib.sha512()
    with urllib.request.urlopen(req, timeout=60) as resp, open(tmp, "wb") as fh:
        while chunk := resp.read(1 << 16):
            fh.write(chunk)
            digest.update(chunk)
    if sha512 and digest.hexdigest() != sha512:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("The download was corrupted. Try again.")
    tmp.replace(dest)


def install_modrinth_project(project_id, inst, seen, depth=0):
    if project_id in seen or depth > 3:
        return []
    seen.add(project_id)
    tags = MOD_LOADER_TAGS[inst["loader"]]
    query = urllib.parse.urlencode({
        "game_versions": json.dumps([inst["mc_version"]]),
        "loaders": json.dumps(tags),
    })
    versions = http_json(f"{MODRINTH}/project/{project_id}/version?{query}")
    if not versions:
        raise RuntimeError("No compatible version of this mod exists for your instance.")
    version = versions[0]
    file = next((f for f in version["files"] if f.get("primary")), version["files"][0])
    dest = mods_dir(inst["id"]) / safe_name(file["filename"])
    installed = []
    if not dest.exists():
        download(file["url"], dest, file.get("hashes", {}).get("sha512"))
        installed.append(file["filename"])
    for dep in version.get("dependencies", []):
        if dep.get("dependency_type") == "required" and dep.get("project_id"):
            installed += install_modrinth_project(dep["project_id"], inst, seen, depth + 1)
    return installed


# --------------------------------------------------------------------------- background media

MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
        ".gif": "image/gif", ".bmp": "image/bmp", ".mp4": "video/mp4", ".m4v": "video/mp4",
        ".webm": "video/webm",
        ".ttf": "font/ttf", ".otf": "font/otf", ".woff": "font/woff", ".woff2": "font/woff2"}


class MediaHandler(BaseHTTPRequestHandler):
    """Serves the chosen background to the launcher window only (127.0.0.1), with Range support for video."""

    def do_GET(self):
        raw = urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        base = FONT_DIR if raw.startswith("/font/") else BG_DIR
        name = Path(raw).name
        path = base / name
        if not name or not path.is_file():
            self.send_error(404)
            return
        size = path.stat().st_size
        start, end, status = 0, size - 1, 200
        match = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if match and (match.group(1) or match.group(2)):
            if match.group(1):
                start = int(match.group(1))
                if match.group(2):
                    end = min(int(match.group(2)), size - 1)
            else:
                start = max(size - int(match.group(2)), 0)
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.end_headers()
                return
            status = 206
        self.send_response(status)
        self.send_header("Content-Type", MIME.get(path.suffix.lower(), "application/octet-stream"))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(end - start + 1))
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        try:
            with open(path, "rb") as fh:
                fh.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = fh.read(min(1 << 16, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def log_message(self, *args):
        pass


def start_media_server():
    BG_DIR.mkdir(parents=True, exist_ok=True)
    FONT_DIR.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), MediaHandler)
    MEDIA["port"] = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()


def prune_backgrounds():
    keep = STATE["settings"]["bg"].get("file")
    for path in BG_DIR.glob("*"):
        if path.is_file() and path.name != keep:
            path.unlink(missing_ok=True)


# --------------------------------------------------------------------------- JS bridge

class Api:
    """Every public method here is callable from the UI as pywebview.api.<name>()."""

    def boot(self):
        return public_state()

    def mc_versions(self):
        try:
            items = mll.utils.get_version_list()
            return {"ok": True, "versions": [v["id"] for v in items if v["type"] == "release"]}
        except Exception:
            return {"ok": False, "error": "Could not reach Mojang to list versions. Check your connection."}

    # ----- instances
    def create_instance(self, name, mc_version, loader, ram_mb):
        name = (name or "").strip() or f"Minecraft {mc_version}"
        if loader not in LOADERS:
            return {"ok": False, "error": "Unknown loader."}
        inst = {
            "id": uuidlib.uuid4().hex[:8],
            "name": name[:40],
            "mc_version": mc_version,
            "loader": loader,
            "ram_mb": int(ram_mb),
            "installed": False,
            "last_played": 0,
        }
        STATE["instances"].append(inst)
        STATE["selected"] = inst["id"]
        (INST_DIR / inst["id"] / "mods").mkdir(parents=True, exist_ok=True)
        save_state()
        return {"ok": True, "state": public_state()}

    def update_instance(self, iid, name, ram_mb):
        inst = find_instance(iid)
        inst["name"] = (name or inst["name"]).strip()[:40]
        inst["ram_mb"] = int(ram_mb)
        save_state()
        return public_state()

    def delete_instance(self, iid):
        inst = find_instance(iid)
        STATE["instances"].remove(inst)
        if STATE["selected"] == iid:
            STATE["selected"] = STATE["instances"][0]["id"] if STATE["instances"] else None
        save_state()
        return public_state()

    def select_instance(self, iid):
        find_instance(iid)
        STATE["selected"] = iid
        save_state()
        return public_state()

    def open_instance_folder(self, iid):
        open_path(INST_DIR / find_instance(iid)["id"])
        return True

    # ----- settings and account
    def save_settings(self, values):
        cfg = STATE["settings"]
        if "client_id" in values:
            cfg["client_id"] = str(values["client_id"])
        if "ram_mb" in values:
            cfg["ram_mb"] = int(values["ram_mb"])
        if "lights" in values:
            cfg["lights"] = bool(values["lights"])
        if "theme" in values:
            theme = values["theme"]
            if theme is None:
                cfg["theme"] = None
            else:
                colors = {k: str(v) for k, v in theme.get("colors", {}).items()
                          if k in THEME_KEYS and HEX_COLOR.match(str(v))}
                if set(colors) == set(THEME_KEYS):
                    cfg["theme"] = {"preset": str(theme.get("preset", "custom"))[:20], "colors": colors}
        if "font" in values:
            font = values["font"]
            family = font.get("family", "bricolage")
            file = Path(str(cfg["font"].get("file") or "")).name
            if family not in FONT_KEYS or (family == "custom" and not (FONT_DIR / file).is_file()):
                family = "bricolage"
            cfg["font"] = {"family": family, "file": file or None,
                           "scale": min(max(float(font.get("scale", 1.0)), 0.85), 1.25)}
        if "effect" in values:
            fx = values["effect"] or {}
            kind = fx.get("kind") if fx.get("kind") in EFFECT_KEYS else "embers"
            cfg["effect"] = {"kind": kind, "amount": min(max(float(fx.get("amount", 1.0)), 0.3), 2.0),
                             "front": bool(fx.get("front", True))}
        if "force_motion" in values:
            cfg["force_motion"] = bool(values["force_motion"])
        if "perf" in values:
            cfg["perf"] = {k: bool(values["perf"].get(k, cfg["perf"].get(k, True)))
                           for k in ("jvm_flags", "high_priority", "prewarm")}
        if "bg" in values:
            bg = values["bg"]
            kind = bg.get("kind", "none")
            file = Path(str(bg.get("file") or "")).name
            if kind not in ("image", "video") or not (BG_DIR / file).is_file():
                kind, file = "none", None
            cfg["bg"] = {
                "kind": kind,
                "file": file,
                "dim": min(max(float(bg.get("dim", 0.45)), 0.0), 0.95),
                "blur": min(max(float(bg.get("blur", 0)), 0.0), 24.0),
            }
            prune_backgrounds()
        save_state()
        return public_state()

    def pick_background(self, kind):
        """Asks for an image or video file and copies it into Xamhub's own folder."""
        if kind not in ("image", "video"):
            return {"ok": False, "error": "Unknown background type."}
        exts = IMAGE_EXT if kind == "image" else VIDEO_EXT
        label = ("Images (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp)" if kind == "image"
                 else "Videos (*.mp4;*.webm)")
        dialog = webview.FileDialog.OPEN if hasattr(webview, "FileDialog") else webview.OPEN_DIALOG
        picked = WINDOW.create_file_dialog(dialog, allow_multiple=False, file_types=(label,))
        if not picked:
            return {"ok": False, "cancelled": True}
        src = Path(picked[0])
        if src.suffix.lower() not in exts:
            return {"ok": False, "error": f"Choose a {kind} file ({', '.join(sorted(exts))})."}
        if src.stat().st_size > MAX_BG_BYTES:
            return {"ok": False, "error": "That file is larger than 150 MB."}
        BG_DIR.mkdir(parents=True, exist_ok=True)
        name = f"{kind}-{int(time.time())}{src.suffix.lower()}"
        shutil.copyfile(src, BG_DIR / name)
        return {"ok": True, "file": name, "kind": kind}

    def pick_font(self):
        dialog = webview.FileDialog.OPEN if hasattr(webview, "FileDialog") else webview.OPEN_DIALOG
        picked = WINDOW.create_file_dialog(dialog, allow_multiple=False,
                                           file_types=("Fonts (*.ttf;*.otf;*.woff;*.woff2)",))
        if not picked:
            return {"ok": False, "cancelled": True}
        src = Path(picked[0])
        if src.suffix.lower() not in FONT_EXT:
            return {"ok": False, "error": "Choose a .ttf, .otf, .woff or .woff2 font file."}
        if src.stat().st_size > 20 * 1024 * 1024:
            return {"ok": False, "error": "That font file is larger than 20 MB."}
        FONT_DIR.mkdir(parents=True, exist_ok=True)
        name = f"font-{int(time.time())}{src.suffix.lower()}"
        shutil.copyfile(src, FONT_DIR / name)
        for old in FONT_DIR.glob("*"):
            if old.is_file() and old.name != name:
                old.unlink(missing_ok=True)
        STATE["settings"]["font"] = dict(STATE["settings"]["font"], family="custom", file=name)
        save_state()
        return {"ok": True, "state": public_state()}

    def list_worlds(self, iid):
        saves = INST_DIR / find_instance(iid)["id"] / "saves"
        if not saves.is_dir():
            return []
        worlds = [d for d in saves.iterdir() if (d / "level.dat").is_file()]
        worlds.sort(key=lambda d: d.stat().st_mtime, reverse=True)
        return [d.name for d in worlds]

    def set_quick_play(self, iid, kind, target):
        inst = find_instance(iid)
        if kind not in ("none", "world", "server"):
            kind = "none"
        inst["quick_play"] = {"type": kind, "target": "" if kind == "none" else str(target or "").strip()[:200]}
        save_state()
        return public_state()

    def install_perf_pack(self, iid):
        inst = find_instance(iid)
        if inst["loader"] == "vanilla":
            return {"ok": False, "error": "Performance mods need a Fabric, Quilt or Forge instance."}
        installed, skipped, seen = [], [], set()
        for slug in PERF_MODS[inst["loader"]]:
            try:
                installed += install_modrinth_project(slug, inst, seen)
            except Exception:
                skipped.append(slug)
        return {"ok": True, "installed": installed, "skipped": skipped}

    def prewarm(self, iid):
        if not STATE["settings"]["perf"].get("prewarm", True):
            return {"warm": False}
        if iid in WARM["done"]:
            return {"warm": True}
        if iid not in WARM["running"]:
            WARM["running"].add(iid)
            threading.Thread(target=warm_instance, args=(iid,), daemon=True).start()
        return {"warm": False}

    def discard_background(self, file):
        if file != STATE["settings"]["bg"].get("file"):
            (BG_DIR / safe_name(file)).unlink(missing_ok=True)
        return True

    # ----- account
    def login(self):
        """Opens a small Microsoft sign-in pop-up and waits for Microsoft to hand the account back."""
        cid = STATE["settings"]["client_id"].strip()
        if not cid:
            return {"ok": False, "need_client_id": True,
                    "error": "Add your Microsoft app client ID in Settings first."}
        if LOGIN["active"]:
            return {"ok": False, "error": "Sign-in is already open in your browser."}

        result = {}
        got = threading.Event()

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if "code" in query or "error" in query:
                    result["url"] = REDIRECT_URI + self.path
                    good = "code" in query
                    title = "You're signed in" if good else "Sign-in failed"
                    msg = "You can close this tab and go back to Xamhub." if good else "Close this tab and try again in Xamhub."
                    got.set()
                else:
                    title, msg = "Xamhub", "Waiting for Microsoft sign-in."
                body = LOGIN_PAGE.replace("TITLE", title).replace("MSG", msg).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        try:
            server = HTTPServer(("127.0.0.1", LOGIN_PORT), Handler)
        except OSError:
            return {"ok": False, "error": f"Port {LOGIN_PORT} is busy. Close other launchers and try again."}

        LOGIN["active"] = True
        LOGIN["cancel"].clear()
        popup = None
        try:
            url, state, verifier = mll.microsoft_account.get_secure_login_data(cid, REDIRECT_URI)
            LOGIN["url"] = url
            emit("login_link", url=url)
            popup = webview.create_window("Sign in to Microsoft", url, width=480, height=660, resizable=False)
            server.timeout = 0.5
            deadline = time.time() + 600
            while not got.is_set() and not LOGIN["cancel"].is_set() and time.time() < deadline:
                server.handle_request()
            if not got.is_set():
                return {"ok": False, "cancelled": True, "error": "Sign-in was cancelled."}
            code = mll.microsoft_account.parse_auth_code_url(result["url"], state)
            data = mll.microsoft_account.complete_login(cid, None, REDIRECT_URI, code, verifier)
            STATE["account"] = account_from(data)
            save_state()
            return {"ok": True, "state": public_state()}
        except mll.exceptions.AccountNotOwnMinecraft:
            return {"ok": False, "error": "This Microsoft account does not own Minecraft: Java Edition."}
        except Exception as exc:
            return {"ok": False, "error": f"Sign-in failed: {exc}"}
        finally:
            LOGIN["active"] = False
            server.server_close()
            if popup is not None:
                try:
                    popup.destroy()
                except Exception:
                    pass  # already closed by the user
            emit("login_end")

    def cancel_login(self):
        LOGIN["cancel"].set()
        return True

    def reopen_login(self):
        if LOGIN["url"]:
            webbrowser.open(LOGIN["url"])
        return True

    def logout(self):
        STATE["account"] = None
        save_state()
        return public_state()

    # ----- playing
    def play(self, iid):
        if GAME["busy"]:
            return {"ok": False, "error": "A game is already running."}
        if not STATE["account"]:
            return {"ok": False, "error": "Sign in with Microsoft first."}
        try:
            find_instance(iid)
        except KeyError as exc:
            return {"ok": False, "error": str(exc)}
        GAME["busy"] = True
        threading.Thread(target=run_instance, args=(iid,), daemon=True).start()
        return {"ok": True}

    def stop(self):
        proc = GAME.get("proc")
        if proc and proc.poll() is None:
            proc.terminate()
        return True

    # ----- mods
    def list_mods(self, iid):
        out = []
        for path in sorted(mods_dir(iid).iterdir(), key=lambda p: p.name.lower()):
            if path.name.endswith(".jar") or path.name.endswith(".jar.disabled"):
                enabled = path.name.endswith(".jar")
                label = re.sub(r"\.jar(\.disabled)?$", "", path.name)
                out.append({"file": path.name, "name": label, "enabled": enabled,
                            "size": path.stat().st_size})
        return out

    def add_mods(self, iid):
        kind = webview.FileDialog.OPEN if hasattr(webview, "FileDialog") else webview.OPEN_DIALOG
        picked = WINDOW.create_file_dialog(kind, allow_multiple=True, file_types=("Mod files (*.jar)",))
        added = 0
        for src in picked or []:
            src = Path(src)
            if src.suffix == ".jar":
                (mods_dir(iid) / src.name).write_bytes(src.read_bytes())
                added += 1
        return {"added": added}

    def toggle_mod(self, iid, file):
        path = mods_dir(iid) / safe_name(file)
        if file.endswith(".disabled"):
            path.rename(path.with_name(file[: -len(".disabled")]))
        else:
            path.rename(path.with_name(file + ".disabled"))
        return True

    def remove_mod(self, iid, file):
        (mods_dir(iid) / safe_name(file)).unlink(missing_ok=True)
        return True

    def open_mods_folder(self, iid):
        open_path(mods_dir(iid))
        return True

    def search_mods(self, iid, query):
        inst = find_instance(iid)
        if inst["loader"] == "vanilla":
            return {"ok": False, "error": "Vanilla has no mod support. Create a Fabric, Quilt or Forge instance."}
        facets = [["project_type:mod"], [f"versions:{inst['mc_version']}"],
                  [f"categories:{tag}" for tag in MOD_LOADER_TAGS[inst["loader"]]]]
        params = {"limit": 20, "facets": json.dumps(facets)}
        if query.strip():
            params["query"] = query.strip()
        else:
            params["index"] = "downloads"
        try:
            data = http_json(f"{MODRINTH}/search?{urllib.parse.urlencode(params)}")
        except Exception:
            return {"ok": False, "error": "Could not reach Modrinth. Check your connection."}
        hits = [{"id": h["project_id"], "title": h["title"], "description": h["description"],
                 "icon": h.get("icon_url"), "downloads": h["downloads"], "author": h["author"]}
                for h in data.get("hits", [])]
        return {"ok": True, "hits": hits}

    def install_mod(self, iid, project_id):
        inst = find_instance(iid)
        try:
            files = install_modrinth_project(project_id, inst, set())
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "files": files}


def main():
    global WINDOW
    ROOT.mkdir(parents=True, exist_ok=True)
    start_media_server()
    WINDOW = webview.create_window(
        "Xamhub", str(UI_FILE), js_api=Api(), width=1120, height=730,
        min_size=(900, 620), background_color="#14151c",
    )
    webview.start(debug=bool(os.environ.get("XAMHUB_DEBUG")))


if __name__ == "__main__":
    main()
