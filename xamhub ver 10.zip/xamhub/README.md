# Xamhub

A Minecraft: Java Edition launcher with Fabric, Quilt and Forge support, a Modrinth mod browser,
synthesised sound effects and a UI that reacts with light.

## Run it

    pip install -r requirements.txt
    python app.py

Needs Python 3.9+. Linux also needs a pywebview backend (`pip install pywebview[qt]` or GTK).

## Microsoft sign-in (one-time setup)

Xamhub signs in with your own Microsoft app registration. When you press sign in, a small Microsoft
sign-in window pops up (with a browser link as a backup), and Xamhub connects automatically when you finish:

1. Go to the Azure portal > Microsoft Entra ID > App registrations > New registration.
2. Supported account types: "Personal Microsoft accounts only".
3. Redirect URI: platform "Mobile and desktop applications",
   value `http://localhost:53682` (exactly this, including the port).
4. Under Authentication, allow public client flows.
5. Copy the Application (client) ID into Xamhub > Settings.

Mojang currently requires new app registrations to be approved before they can use the Minecraft
services API (see https://aka.ms/AppRegInfo). Until that is approved, sign-in may fail with an
"Invalid app registration" error. This applies to every third-party launcher.

## What it does

- Instances: each has its own version, loader, memory setting, mods and worlds (`~/.xamhub/instances/<id>`).
- Shared game files (versions, libraries, assets, Java) live in `~/.xamhub/minecraft`, so they download once.
- Mods: search and install from Modrinth (required dependencies such as Fabric API are fetched
  automatically and hash-checked), add .jar files by hand, switch mods on or off, remove them.
- Lights: the strip along the top edge shows state (accent color idle, green working, white running,
  red error), and a light travels around any button you press. Turn lights off in Settings.
- Themes: pick a preset or mix your own five colors in Settings. Everything recolors live.
- Background: use an image, or a video of up to 10 seconds (looped, muted). Darken and blur sliders keep
  text readable. The file is copied into `~/.xamhub/backgrounds`, and only one is kept at a time.

- Background effects: embers, snow, rain, fireflies, cherry petals or stars, with an amount slider.
- Fonts: pick a preset font or load your own .ttf/.otf/.woff file, and scale the text size.
- Speed: tuned Java garbage-collection flags, higher process priority on Windows, a one-click
  performance pack (Sodium/Embeddium, Lithium, FerriteCore, ModernFix, EntityCulling, ImmediatelyFast),
  a background warm-up that refreshes sign-in and pre-loads game files, and "Start in", which uses
  Quick Play (Minecraft 1.20+) to skip the title screen and load a world or join a server directly.

## Notes

- Tokens are stored in plain JSON at `~/.xamhub/xamhub.json`. Keep that file private.
- Set `XAMHUB_HOME` to move the data folder and `XAMHUB_DEBUG=1` to open dev tools.
- To make a standalone app: `pip install pyinstaller` then
  `pyinstaller --noconsole --add-data "ui;ui" app.py` (use `ui:ui` on macOS/Linux).
